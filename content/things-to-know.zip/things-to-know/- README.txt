This folder contains files created by the Notenik application.

Learn more at https://Notenik.app
